#!/bin/sh
# IsyWeb — installation sous Linux.
#
#   ./install.sh               ordinateur avec écran : menu des applications (sans sudo)
#   ./install.sh --service     machine sans écran (Raspberry Pi, serveur, conteneur) :
#                              service systemd + accès depuis le réseau local
#   ./install.sh --uninstall   désinstallation (les réglages sont conservés)
set -eu

DIR=$(cd "$(dirname "$0")" && pwd)
APP=isyweb
MODE=${1:-desktop}

if [ "$(id -u)" -eq 0 ]; then
	BIN=/usr/local/bin
	UNIT=/etc/systemd/system/$APP.service
	SYSTEMCTL="systemctl"
else
	BIN=$HOME/.local/bin
	UNIT=${XDG_CONFIG_HOME:-$HOME/.config}/systemd/user/$APP.service
	SYSTEMCTL="systemctl --user"
fi
SHARE=${XDG_DATA_HOME:-$HOME/.local/share}
[ "$(id -u)" -eq 0 ] && SHARE=/usr/local/share
DESKTOP=$SHARE/applications/$APP.desktop
ICON=$SHARE/icons/hicolor/512x512/apps/$APP.png

say() { printf '%s\n' "$*"; }

stop_running() {
	if [ -f "$UNIT" ]; then $SYSTEMCTL stop $APP 2>/dev/null || true; fi
	if [ -x "$BIN/$APP" ]; then "$BIN/$APP" --quit >/dev/null 2>&1 || true; fi
}

install_files() {
	if [ ! -f "$DIR/$APP" ]; then
		say "Fichier « $APP » introuvable à côté de ce script : décompressez toute l'archive avant de lancer l'installation."
		exit 1
	fi
	mkdir -p "$BIN" "$(dirname "$DESKTOP")" "$(dirname "$ICON")"
	cp "$DIR/$APP" "$BIN/$APP.new" && chmod 755 "$BIN/$APP.new" && mv -f "$BIN/$APP.new" "$BIN/$APP"
	[ -f "$DIR/$APP.png" ] && cp "$DIR/$APP.png" "$ICON"
}

case "$MODE" in
--uninstall)
	stop_running
	if [ -f "$UNIT" ]; then
		$SYSTEMCTL disable --now $APP 2>/dev/null || true
		rm -f "$UNIT"
		$SYSTEMCTL daemon-reload 2>/dev/null || true
	fi
	"$BIN/$APP" --autostart off >/dev/null 2>&1 || true
	rm -f "$BIN/$APP" "$DESKTOP" "$ICON"
	say "IsyWeb est désinstallé."
	say "Vos réglages restent dans ${XDG_CONFIG_HOME:-$HOME/.config}/IsyWeb (supprimez ce dossier pour les effacer)."
	;;

--service)
	if ! command -v systemctl >/dev/null 2>&1; then
		say "systemd est introuvable sur cette machine."
		say "Lancez IsyWeb à la main : $DIR/$APP --no-browser"
		exit 1
	fi
	if ! $SYSTEMCTL show-environment >/dev/null 2>&1; then
		if [ "$(id -u)" -eq 0 ]; then
			say "systemd ne répond pas (conteneur sans systemd ?)."
		else
			say "Le systemd de votre utilisateur ne répond pas (session SSH sans bus, par exemple)."
			say "Au choix : relancez avec sudo pour un service système (sudo ./install.sh --service),"
			say "ou exécutez « sudo loginctl enable-linger $(id -un) », reconnectez-vous et relancez ce script."
		fi
		say "Sinon, lancez IsyWeb à la main : $DIR/$APP --no-browser"
		exit 1
	fi
	stop_running
	install_files
	mkdir -p "$(dirname "$UNIT")"
	if [ "$(id -u)" -eq 0 ]; then
		WANTED=multi-user.target
		EXEC=$BIN/$APP
		USERLINE="User=root" # fixe HOME=/root : mêmes réglages que la commande « isyweb » lancée en root
	else
		USERLINE=""
		WANTED=default.target
		EXEC=%h/.local/bin/$APP
	fi
	cat >"$UNIT" <<EOF
[Unit]
Description=IsyWeb — suivi de l'installation Isypower
Wants=network-online.target
After=network-online.target

[Service]
$USERLINE
ExecStart=$EXEC --no-browser
Restart=on-failure
RestartSec=5
NoNewPrivileges=true

[Install]
WantedBy=$WANTED
EOF
	$SYSTEMCTL daemon-reload
	$SYSTEMCTL enable --now $APP
	if [ "$(id -u)" -ne 0 ]; then
		# Sans « linger », le service s'arrête quand l'utilisateur se déconnecte.
		loginctl enable-linger "$(id -un)" 2>/dev/null ||
			say "Pour qu'IsyWeb tourne même sans session ouverte : sudo loginctl enable-linger $(id -un)"
	fi
	sleep 1
	"$BIN/$APP" --lan on >/dev/null
	say "IsyWeb est installé et démarré comme service."
	say ""
	"$BIN/$APP" --status
	say ""
	say "Sur un téléphone ou un PC de la maison, ouvrez l'adresse ci-dessus et saisissez le code."
	say "Commandes utiles : $APP --status · $APP --lan-revoke · $APP --lan off"
	case ":$PATH:" in *":$BIN:"*) ;; *) say "(Ajoutez $BIN à votre PATH, ou utilisez $BIN/$APP)" ;; esac
	;;

desktop | --desktop)
	stop_running
	install_files
	cat >"$DESKTOP" <<EOF
[Desktop Entry]
Type=Application
Name=IsyWeb
GenericName=Suivi solaire Isypower
Comment=Suivre son installation Isypower dans le navigateur
Exec=$BIN/$APP
Icon=$APP
Terminal=false
Categories=Utility;
Keywords=isypower;solaire;batterie;energie;
StartupNotify=false
EOF
	command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$(dirname "$DESKTOP")" 2>/dev/null || true
	command -v gtk-update-icon-cache >/dev/null 2>&1 && gtk-update-icon-cache -q "$SHARE/icons/hicolor" 2>/dev/null || true
	say "IsyWeb est installé : retrouvez-le dans le menu des applications (« IsyWeb »)."
	say "Démarrage automatique à l'ouverture de session : $APP --autostart on"
	if [ -n "${DISPLAY:-}${WAYLAND_DISPLAY:-}" ]; then
		nohup "$BIN/$APP" >/dev/null 2>&1 &
		say "IsyWeb s'ouvre dans votre navigateur."
	else
		say ""
		say "Aucun écran détecté (connexion à distance, serveur, machine virtuelle ?) : IsyWeb n'a pas été lancé."
		say "Pour qu'il tourne en permanence et s'utilise depuis un téléphone ou un PC de la maison :"
		say "    ./install.sh --service"
	fi
	;;

*)
	say "Usage : ./install.sh [--service | --uninstall]"
	exit 1
	;;
esac
